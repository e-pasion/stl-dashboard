let menu=document.getElementById("menu");
document.getElementById("menuOpen").addEventListener("click",(()=>{
    menu.classList.toggle("w-60")
}))