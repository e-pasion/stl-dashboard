var selectColor=document.getElementById("selectColor")

selectColor.addEventListener(("input"),()=>{
    document.getElementById("colorCode").value=selectColor.value;
    stl_viewer.set_color(0, selectColor.value);

})

var stl_viewer=new StlViewer(document.getElementById("cuboContenedor"), { models: [ {id:0, filename:"cube.stl",color:"#000000"} ],auto_resize:false,zoom:-3 });

